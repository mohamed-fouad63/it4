
 function printer_status(printer_data) {
      $.ajax({
        url: '/it4/ajaxPrinterStatus',
        type: 'post',
        data:printer_data,
        success: function(data) {
        $('.popover-header').text(data.name+' * '+data.ready+' * '+data.toner);
        $('.popover-body').text(data.notReady);
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.log(jqXHR);
  
        }
      });
    };


